library(Imap)
library(vegan)

###read geographical matrix function
#function to get geographical distances
#from https://eurekastatistics.com/calculating-a-distance-matrix-for-geographic-points-using-r/
ReplaceLowerOrUpperTriangle <- function(m, triangle.to.replace){
  # If triangle.to.replace="lower", replaces the lower triangle of a square matrix with its upper triangle.
  # If triangle.to.replace="upper", replaces the upper triangle of a square matrix with its lower triangle.
  
  if (nrow(m) != ncol(m)) stop("Supplied matrix must be square.")
  if      (tolower(triangle.to.replace) == "lower") tri <- lower.tri(m)
  else if (tolower(triangle.to.replace) == "upper") tri <- upper.tri(m)
  else stop("triangle.to.replace must be set to 'lower' or 'upper'.")
  m[tri] <- t(m)[tri]
  return(m)
}

GeoDistanceInMetresMatrix <- function(df.geopoints){
  # Returns a matrix (M) of distances between geographic points.
  # M[i,j] = M[j,i] = Distance between (df.geopoints$lat[i], df.geopoints$lon[i]) and
  # (df.geopoints$lat[j], df.geopoints$lon[j]).
  # The row and column names are given by df.geopoints$name.
    GeoDistanceInMetres <- function(g1, g2){
    # Returns a vector of distances. (But if g1$index > g2$index, returns zero.)
    # The 1st value in the returned vector is the distance between g1[[1]] and g2[[1]].
    # The 2nd value in the returned vector is the distance between g1[[2]] and g2[[2]]. Etc.
    # Each g1[[x]] or g2[[x]] must be a list with named elements "index", "lat" and "lon".
    # E.g. g1 <- list(list("index"=1, "lat"=12.1, "lon"=10.1), list("index"=3, "lat"=12.1, "lon"=13.2))
    DistM <- function(g1, g2){
      require("Imap")
      return(ifelse(g1$index > g2$index, 0, gdist(lat.1=g1$lat, lon.1=g1$lon, lat.2=g2$lat, lon.2=g2$lon, units="m")))
    }
    return(mapply(DistM, g1, g2))
  }
  
  n.geopoints <- nrow(df.geopoints)
    # The index column is used to ensure we only do calculations for the upper triangle of points
  df.geopoints$index <- 1:n.geopoints
    # Create a list of lists
  list.geopoints <- by(df.geopoints[,c("index", "lat", "lon")], 1:n.geopoints, function(x){return(list(x))})
    # Get a matrix of distances (in metres)
  mat.distances <- ReplaceLowerOrUpperTriangle(outer(list.geopoints, list.geopoints, GeoDistanceInMetres), "lower")
    # Set the row and column names
  rownames(mat.distances) <- df.geopoints$name
  colnames(mat.distances) <- df.geopoints$name
    return(mat.distances)
}
###end of reading function 


#load meta table for latitude,longitude info
meta<-read.csv("DrosEUmetadata.csv",header=T)
meta<-meta[order(meta$Sample),]
row.names(meta)<-c(1:length(meta[[1]]))

#calculate geographic distance
df.cities <- data.frame(name =meta$Sample,  lat  = meta$lat, lon  = meta$long)
geodist=GeoDistanceInMetresMatrix(df.cities) / 1000


#load OTU table and calculate bray curtis matrix
shared100<-read.table("start.droseu.unique.subsample.shared",header=T) #output from mothur analysis
shared100=shared100[,-1]
shared100=shared100[,-2]
shared100=data.frame(shared100[,-1],row.names = as.vector(shared100[,1]))
braymatrix=as.matrix(vegdist(shared100))

#mantel test
mantel(braymatrix,geodist,permutations=9999)$statistic
mantel(braymatrix,geodist,permutations=9999)$signif


##fig 1b
library(ggplot2)
x=as.vector(as.dist(geodist))
y=as.vector(as.dist(braymatrix))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.35),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  labs(x = "geographic distance in km",y = "bacterial community dissimilarity")+
  theme(axis.text=element_text(size=16,face="bold",colour = "black"),axis.title=element_text(size=17.5,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=2800, y=0.3, label="\nP = 0.0015\nr = 0.20\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1)

##fig S3a
#read pariwise fst table
fst=read.csv("DrosEU-FST_Geo_update.csv",header = T)
fst=fst[order(fst$Population1),]
fst=fst[fst$Population1!='s51',]
fst=fst[fst$Population2!='s51',]
droplevels(fst)->fst
fst.mat=as.matrix(xtabs(fst[, 3] ~ fst[, 2] + fst[, 1]))
s1=c(0,rep(0,dim(fst.mat)[2]-1))
names(s1)=colnames(fst.mat)
as.dist(rbind(s1,fst.mat))

#remove samples in meta table and shared file without fst infomation
meta[c(-9,-35,-47),]->meta
df.cities <- data.frame(name =meta$Sample,  lat  = meta$lat, lon  = meta$long)
geodist=GeoDistanceInMetresMatrix(df.cities) / 1000
shared100[c(-9,-35,-47),]->shared100
braymatrix=as.matrix(vegdist(shared100))

#do partial mantel test
mantel.partial(as.dist(braymatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$statistic 
#0.1855181
mantel.partial(as.dist(braymatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$signif 
#0.0211

#plot fig S3a
x=as.vector(as.dist(rbind(s1,fst.mat)))
y=as.vector(resid(lm(as.vector(as.dist(braymatrix))~as.vector(as.dist(geodist)))))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.3),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  # labs(x = expression("pairwise F"[ST]),y = "residual community dissimilarity")+
  labs(x ="pairwise Fst",y = "residual community dissimilarity")+
  theme(axis.text=element_text(size=15,face="bold",colour = "black"),axis.title=element_text(size=16,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  # scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=0.0375, y=-0.4, label="\nP = 0.02\nr = 0.19\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1.25,col='black')


######using different distance metrics for
#fig S3bcde
#jaccard index
jmatrix=as.matrix(vegdist(shared100,method="jaccard"))
mantel(jmatrix,geodist,permutations=9999)$statistic  #0.2040113
mantel(jmatrix,geodist,permutations=9999)$signif #8e-04
#partial mantel test
mantel.partial(as.dist(jmatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$statistic #0.1895445
mantel.partial(as.dist(jmatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$signif #0.0168

#morisita-horn index
hmatrix=as.matrix(vegdist(shared100,method="horn"))
mantel(hmatrix,geodist,permutations=9999)$statistic  #0.1827412
mantel(hmatrix,geodist,permutations=9999)$signif #0.001
#partial mantel test
mantel.partial(as.dist(hmatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$statistic #0.1622406
mantel.partial(as.dist(hmatrix),as.dist(rbind(s1,fst.mat)),as.dist(geodist),permutations=9999)$signif #0.0267

x=as.vector(as.dist(geodist))
#figs3b
png("fig.mantel.jaccard.png", width = 550, height = 500,res = 100)
y=as.vector(as.dist(jmatrix))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.3),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  labs(title="jaccard",x = "geographic distance in km",y = "bacterial community dissimilarity")+
  theme(plot.title = element_text(size=17.5,face="bold",colour = "black",hjust = 0.5),
        axis.text=element_text(size=16,face="bold",colour = "black"),
        axis.title=element_text(size=17.5,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=2800, y=0.3, label="\nP = 0.0008\nr = 0.20\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1.25,col='black')
dev.off()
#figure s3d
png("fig.mantel.horn-morisita.png", width = 550, height = 500,res = 100)
y=as.vector(as.dist(hmatrix))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.3),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  labs(title="horn-morisita",x = "geographic distance in km",y = "bacterial community dissimilarity")+
  theme(plot.title = element_text(size=17.5,face="bold",colour = "black",hjust = 0.5),
        axis.text=element_text(size=16,face="bold",colour = "black"),
        axis.title=element_text(size=17.5,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=2800, y=0.3, label="\nP = 0.0010\nr = 0.18\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1.25,col='black')
dev.off()
#residual plot
x=as.vector(as.dist(rbind(s1,fst.mat)))
#figure s3c
png("fig.mantel.jaccard.resid.png", width = 550, height = 500,res = 100)
y=as.vector(resid(lm(as.vector(as.dist(jmatrix))~as.vector(as.dist(geodist)))))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.3),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  # labs(x = expression("pairwise F"[ST]),y = "residual community dissimilarity")+
  labs(title="jaccard",x ="pairwise Fst",y = "residual community dissimilarity")+
  theme(plot.title = element_text(size=17.5,face="bold",colour = "black",hjust = 0.5),
        axis.text=element_text(size=15,face="bold",colour = "black"),
        axis.title=element_text(size=16,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  # scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=0.0375, y=-0.4, label="\nP = 0.017\nr = 0.19\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1.25,col='black')
dev.off()
#figure s3e
png("fig.mantel.horn-morisita.resid.png", width = 550, height = 500,res = 100)
y=as.vector(resid(lm(as.vector(as.dist(hmatrix))~as.vector(as.dist(geodist)))))
xy=as.data.frame(cbind(x,y))
ggplot(xy, aes(x=x, y=y)) +
  geom_point( shape=16,color=alpha('darkblue',0.3),cex=2.8)+
  #geom_smooth(method=lm, se=FALSE,linetype="dashed",color="red",size=1)+
  # labs(x = expression("pairwise F"[ST]),y = "residual community dissimilarity")+
  labs(title="horn-morisita",x ="pairwise Fst",y = "residual community dissimilarity")+
  theme(plot.title = element_text(size=17.5,face="bold",colour = "black",hjust = 0.5),
        axis.text=element_text(size=15,face="bold",colour = "black"),
        axis.title=element_text(size=16,face="bold"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        panel.background = element_rect(fill = 'white', colour = 'red'),
        panel.grid.major =element_line(colour = 'grey'))+
  # scale_y_continuous(limits = c(0.2, 1))+
  annotate(geom="text", x=0.0375, y=-0.5, label="\nP = 0.027\nr = 0.16\n",
           color="black",size=6,fontface="bold")+
  geom_smooth(method=lm,   # Add linear regression line
              se=FALSE,size=1.25,col='black')
dev.off()


