setwd("/home/f/bwSyncAndShare/Fruitvsfly/Manuskript/supplement")

library(adespatial)
library(vegan)

#load meta table
meta<-read.csv("/home/f/bwSyncAndShare/Fruitvsfly/Manuskript/supplement/DrosEUmetadata_FS.csv",header=T)
meta<-meta[order(meta$Sample),]
row.names(meta)<-c(1:length(meta[[1]]))

#exclude samples have no host genetic differentiation info
meta[c(-9,-35,-47),]->meta


######load and prepare OTU table (output from mothur analysis)
#100% OTU
shared100<-read.table("start.droseu.unique.subsample.shared",header=T)
shared100=shared100[,-1]
shared100=shared100[,-2]
shared100=data.frame(shared100[,-1],row.names = as.vector(shared100[,1]))
#plot columnsums
colSums(shared100)[1:100]
#take OTUs with at least 1000 reads
shared100EU<-shared100[,colSums(shared100[1:length(shared100)])>1000]

#remove samples for which there is no allel frequecy info
shared100EU[c(-9,-35,-47),]->shared100EU

# Hellinger transform the species table
shared100EU.h <- decostand (shared100EU, "hellinger")


########### dbMEM analysis of autocorrelation
#follow the protocol 
#Borcard D., Gillet F. & Legendre P. Numerical Ecology with R, 2018
#chapter 7
library(SoDA)
droseu.xy=geoXY(meta$lat,meta$long)
droseu.xy=as.data.frame(droseu.xy,row.names = rownames(shared100EU.h))

#Is there a linear trend in the data?
anova(rda(shared100EU.h, droseu.xy))	# yes
# Computation of linearly detrended data
shared100EU.h.det <- resid(lm(as.matrix(shared100EU.h) ~ ., data = droseu.xy))
## Step 1. Construct the matrix of dbMEM variables
dbmem.tmp <- dbmem(droseu.xy, silent = FALSE)
dbmem <- as.data.frame(dbmem.tmp)
# Truncation distance used above:
(thr <- give.thresh(dist(droseu.xy)))

# Display and count the eigenvalues
attributes(dbmem.tmp)$values
length(attributes(dbmem.tmp)$values)
# Argument silent = FALSE allows the function to display 
# the truncation level.

## Step 2. Run the global dbMEM analysis on the *detrended*
##    Hellinger-transformed  data
dbmem.rda <- rda(shared100EU.h.det ~ ., dbmem)
anova(dbmem.rda)
#not significant globally


#########rda analysis######
##   at 100% OTU level 
#full model
Mfull.rda=rda(shared100EU.h~AF.PC1+AF.PC2+AF.PC3+tempmonth+precmonth+Precyear+Tempyear+substrate,data=meta)
#null model
M1000.rda<-rda(shared100EU.h~1,data=meta)

#run a global test first
anova(Mfull.rda, permutations = how(nperm = 999))  #0.001
anova(Mfull.rda, permutations = how(nperm = 999),by = "axis")   #3

#model selection
Mordi <- ordistep(M1000.rda, scope=formula(Mfull.rda), direction="forward",permutations = how(nperm = 999))
# AF.PC1 + substrate + AF.PC2 + Tempyear+ (tempmonth) were selected

#followed by backward selection
ordistep(Mordi,scope=formula(M1000.rda),perm.max=1000,direction="backward") # no change

#sense the model
extractAIC(Mordi) #12.00000 -19.90485
RsquareAdj(Mordi) #0.3623468  0.1771852

#examine VIF
vif.cca(Mordi)

#####sense the model with or without axes of host genetic differentiation
####Table S3
#best model from ordistep() but without axes of host genetic differentiation
Mordi.withoutAFPC1PC2 <- rda(shared100EU.h ~ substrate + Tempyear, data = meta)
#add either PC1 or PC2 to the model abova
Mordi.withoutAFPC2 <- rda(shared100EU.h ~ substrate + Tempyear + AF.PC1, data = meta)
Mordi.withoutAFPC1 <- rda(shared100EU.h ~ substrate + Tempyear + AF.PC2, data = meta)
#it is significantly different compared with a model without either PC1 or PC2
anova(Mordi, Mordi.withoutAFPC2)    
anova(Mordi, Mordi.withoutAFPC1)
extractAIC(Mordi.withoutAFPC2)
extractAIC(Mordi.withoutAFPC1)


####Table S4
#if we included latitude and longitude in the full model
#PC1 and PC2 were still selected
Mfull.rda=rda(shared100EU.h~AF.PC1+AF.PC2+AF.PC3+lat+long+tempmonth+precmonth+Precyear+Tempyear+substrate,data=meta)
M1000.rda<-rda(shared100EU.h~1,data=meta)
Mordi <- ordistep(M1000.rda, scope=formula(Mfull.rda), direction="forward",permutations = how(nperm = 999))
#AF.PC1 + substrate + lat + AF.PC2 + long + Precyear 
#it is significantly different compared with a model without PC1
Mordi.withoutAFPC1=rda(shared100EU.h ~ substrate + lat + AF.PC2 + long + Precyear, data = meta)
anova(Mordi, Mordi.withoutAFPC1) #0.001


##
#########rda analysis######  at family level  ##
#Table S5
#load tax.summary file from mothur analysis
data5203=read.table(file="5135start.subsample.nr_v132.wang.tax.summary",header=T) 
#pick taxlevel 5
data5203[data5203$taxlevel==5,]->phyla5203
#pick DrosEu samples
droseu=c("taxlevel","rankID","taxon","daughterlevels","total","D1","D10","D11","D12","D13","D14","D15","D16","D18","D19","D2","D20","D21","D22","D23","D24","D25","D26","D27","D28","D29","D3","D30","D31","D32","D33","D34","D35","D36","D37","D38","D39","D4","D41","D42","D43","D44","D45","D46","D47","D48","D49","D5","D50","D7","D8","D9")
dataeu=data5203[,droseu]
phylaeu=phyla5203[,droseu]

#prepare phyla table
phylaeu2=phylaeu[,-c(1,2,4,5)]
#take a look of sums
plot(phylaeu$total)
#take phyla with at least 1000 reads
phylaeu2=phylaeu2[rowSums(phylaeu2[,-1])>1000,]
rownames(phylaeu2)=phylaeu2$taxon
phylaeu2=phylaeu2[,-1]
phylaeu2=as.data.frame(t(phylaeu2))

## Hellinger transform the species table
phylaeu2.h <- decostand (phylaeu2, "hellinger")
#null model 
M1000.rda<-rda(phylaeu2.h~1,data=meta)
#full model
Mfull.rda=rda(phylaeu2.h~AF.PC1+AF.PC2+AF.PC3+tempmonth+precmonth+Precyear+Tempyear+substrate,data=meta)
#run a global test first
anova(Mfull.rda, permutations = how(nperm = 999)) #0.003

#model seletion
Mordi=ordistep(M1000.rda, scope=formula(Mfull.rda), direction="forward", permutations = how(nperm = 999))
#Tempyear + AF.PC1 were selected

#sense the model
extractAIC(Mordi) #3.00000 -77.23731
RsquareAdj(Mordi) #0.1466827  0.1078955
