####get climate data from worldclim
library(raster)
library(sp)

###get annual temperature and precipitation
r <- getData("worldclim",var="bio",res=10)
r <- r[[c(1,12)]]
names(r) <- c("Temp","Prec")

#load geographic cooridantes
xy=read.csv('DrosEUmetadata.csv',sep=',',header = T)
lats <- xy$lat
lons <- xy$long
coords <- data.frame(x=lons,y=lats)

points <- SpatialPoints(coords, proj4string = r@crs)
values <- extract(r,points)
df <- cbind.data.frame(xy,values)
df

###get tmean data, monthly average temperature
t <- getData("worldclim",var="tmean",res=10)
points <- SpatialPoints(coords, proj4string = t@crs)
values <- extract(t,points)

month=c(7,10,8,7,8,9,10,7,8,7,8,10,10,6,10,6,7,8,7,7,8,10,8,9,8,8,8,9,9,7,6,9,9,10,8,7,8,7,9,9,11,7,10,8,7,9,9,9,10,10)

temp=c()
for (i in 1:nrow(values)) {
  temp=c(temp,as.vector(values[i,m[i]]))
}
temp # average monthly mean temperature (�C * 10)


p <- getData("worldclim",var="prec",res=10)
points <- SpatialPoints(coords, proj4string = p@crs)
values <- extract(p,points)
prec=c()
for (i in 1:nrow(values)) {
  prec=c(prec,as.vector(values[i,m[i]]))
}
prec # average monthly precipitation (mm)
